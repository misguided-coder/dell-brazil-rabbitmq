package com.example.headers;

import java.util.HashMap;
import java.util.Map;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		// Step 1 - Making a connection to broker
		// Broker URL ---- amqp://localhost:8000
		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost"); // localhost
		connectionFactory.setPort(8000); // 5672
		connectionFactory.setUsername("ritesh"); // guest
		connectionFactory.setPassword("secret"); // guest

		Connection connection = connectionFactory.newConnection();

		// Step 2 - Opening a channel to broker using available connection
		// Session which is used to do messaging
		Channel channel = connection.createChannel();
		
		//Preparing headers to attach to message envelope
		Map<String, Object> headers = new HashMap<>();
		//headers.put("country", "india");
		//headers.put("type", "politics");
		headers.put("country", new String[] {"uk","usa"});
		headers.put("type", "weather");
				
		BasicProperties basicProperties = new BasicProperties();
		basicProperties = basicProperties.builder().headers(headers).build();

		// Step 3 - Create a publisher using available channel to send message to an
		// exchange
		String EXCHANGE_NAME = "ex.news";
		
		//channel.basicPublish(EXCHANGE_NAME, "", basicProperties, "Modi will again win the elections".getBytes());
		channel.basicPublish(EXCHANGE_NAME, "", basicProperties, "Wetaher is chilling and very very hot here".getBytes());
			
		System.out.println("Message Sending Done!!!!!");

		// Step 4 - Clean the environment by closing channel and connection
		channel.close();
		connection.close();
	}

}
