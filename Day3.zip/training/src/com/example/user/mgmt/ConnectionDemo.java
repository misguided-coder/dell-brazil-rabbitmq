package com.example.user.mgmt;

import java.util.concurrent.TimeUnit;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class ConnectionDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost");
		connectionFactory.setVirtualHost("JLR");
		connectionFactory.setPort(8000); 
		connectionFactory.setUsername("chicken"); 
		connectionFactory.setPassword("secret"); 
	
		Connection connection = connectionFactory.newConnection();

		System.out.println("Connection is ready!!!!");

		Channel channel = connection.createChannel();

		channel.basicPublish("ex.cars.sports", "sedan", null, "Enjoy Sedan Cars".getBytes());
		
		System.out.println("Message Sending Done!!!!!");
		
		channel.close();
		connection.close();
	}

}
