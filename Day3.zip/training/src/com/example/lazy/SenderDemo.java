package com.example.lazy;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost"); // localhost
		connectionFactory.setPort(8000); // 5672
		connectionFactory.setUsername("ritesh"); // guest
		connectionFactory.setPassword("secret"); // guest
		Connection connection = connectionFactory.newConnection();
		Channel channel = connection.createChannel();
		
		for (int i = 1; i <= 1000; i++) {
			channel.basicPublish("", "EventsQ", null, ("Event No "+i+"").getBytes());
		}

		System.out.println("Message Sending Done!!!!!");

		channel.close();
		connection.close();
	}

}
