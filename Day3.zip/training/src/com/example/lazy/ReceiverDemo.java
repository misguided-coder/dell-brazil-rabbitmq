package com.example.lazy;

import java.io.IOException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.client.AMQP.BasicProperties;

public class ReceiverDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost"); // localhost
		connectionFactory.setPort(8000); // 5672
		connectionFactory.setUsername("ritesh"); // guest
		connectionFactory.setPassword("secret"); // guest
		Connection connection = connectionFactory.newConnection();
		Channel channel = connection.createChannel();
		Consumer consumer = new DefaultConsumer(channel) {

			public void handleDelivery(String consumerTag, Envelope envelope, BasicProperties properties, byte[] body)
					throws IOException {
				System.out.println("Message Received : " + new String(body));
			}
		};

		boolean AUTO_ACK_MODE = true;
		channel.basicConsume("EventsQ", AUTO_ACK_MODE, consumer);

		while (true) {}

	}

}
