package com.example.trace;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost");
		connectionFactory.setVirtualHost("/");
		connectionFactory.setPort(5672);
		connectionFactory.setUsername("guest");
		connectionFactory.setPassword("guest");

		Connection connection = connectionFactory.newConnection();
		Channel channel = connection.createChannel();

		channel.basicPublish("", "GreetingQ", null, "Hello Dear".getBytes());
		
		System.out.println("Message Sending Done!!!!!");

		channel.close();
		connection.close();
	}

}
