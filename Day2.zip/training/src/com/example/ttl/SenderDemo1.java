package com.example.ttl;

import java.util.concurrent.TimeUnit;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo1 {

	public static void main(String[] args) throws Exception {

		// Step 1 - Making a connection to broker
		// Broker URL ---- amqp://localhost:8000
		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost"); // localhost
		connectionFactory.setPort(8000); // 5672
		connectionFactory.setUsername("ritesh"); // guest
		connectionFactory.setPassword("secret"); // guest

		Connection connection = connectionFactory.newConnection();

		// Step 2 - Opening a channel to broker using available connection
		// Session which is used to do messaging
		Channel channel = connection.createChannel();

		// Step 3 - Create a publisher using available channel to send message to an
		// exchange
		String EXCHANGE_NAME = "";
		String ROUTING_KEY = "MovieTicketCounterQ";

		for (int i = 1; i <= 100; i++) {
			channel.basicPublish(EXCHANGE_NAME, ROUTING_KEY, null, ("Ticket No "+i+" is available for sale").getBytes());
		}

		System.out.println("Message Sending Done!!!!!");

		// Step 4 - Clean the environment by closing channel and connection
		channel.close();
		connection.close();
	}

}
