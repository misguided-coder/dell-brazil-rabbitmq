package com.example.persistent;

import java.util.HashMap;
import java.util.Map;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost"); // localhost
		connectionFactory.setPort(8000); // 5672
		connectionFactory.setUsername("ritesh"); // guest
		connectionFactory.setPassword("secret"); // guest
		Connection connection = connectionFactory.newConnection();
		Channel channel = connection.createChannel();
		
		BasicProperties basicProperties = new BasicProperties();
		basicProperties = basicProperties.builder().deliveryMode(2).build();

		channel.basicPublish("", "BooksQ", basicProperties, "RabbitMQ Cookbook".getBytes());
		channel.basicPublish("", "BooksQ", basicProperties, "Headfirst Java".getBytes());
		channel.basicPublish("", "BooksQ", basicProperties, "Java Complete Reference".getBytes());
		channel.basicPublish("", "BooksQ", basicProperties, "Learn Angular 7".getBytes());
			
		System.out.println("Message Sending Done!!!!!");

		// Step 4 - Clean the environment by closing channel and connection
		channel.close();
		connection.close();
	}

}
