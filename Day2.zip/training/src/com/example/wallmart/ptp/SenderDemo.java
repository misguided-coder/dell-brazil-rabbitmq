package com.example.wallmart.ptp;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost"); 
		connectionFactory.setPort(8000); 
		connectionFactory.setVirtualHost("WallMart"); 
		connectionFactory.setUsername("ritesh"); 
		connectionFactory.setPassword("secret");

		Connection connection = connectionFactory.newConnection();
		Channel channel = connection.createChannel();
		
		channel.basicPublish("Customers", "retail", null, "Customer credit limit is $2000".getBytes());

		System.out.println("Message Sending Done!!!!!");

		channel.close();
		connection.close();
	}

}
