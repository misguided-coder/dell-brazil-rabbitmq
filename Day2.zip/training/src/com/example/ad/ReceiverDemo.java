package com.example.ad;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.client.AMQP.BasicProperties;

public class ReceiverDemo {

	public static void main(String[] args) throws Exception {

		// Step 1 - Making a connection to broker
		// Broker URL ---- amqp://localhost:8000
		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost"); // localhost
		connectionFactory.setPort(8000); // 5672
		connectionFactory.setUsername("ritesh"); // guest
		connectionFactory.setPassword("secret"); // guest
		Connection connection = connectionFactory.newConnection();

		// Step 2 - Opening a channel to broker using available connection
		// Session which is used to do messaging
		Channel channel = connection.createChannel();

		// Step 3 - Create a consumer to consume messages from a queue
		Consumer consumer = new DefaultConsumer(channel) {

			public void handleDelivery(String consumerTag, Envelope envelope, BasicProperties properties, byte[] body)
					throws IOException {
				System.out.println("Message Received : " + new String(body));
			}
		};

		// Step 4 - Start consuming messages from a queue as a listener
		boolean AUTO_ACK_MODE = true;
		channel.basicConsume("GamesQ", AUTO_ACK_MODE, consumer);
		
		System.out.println("Consumer is using queue!!!!!");
		TimeUnit.SECONDS.sleep(10);
		
		//while(true) {}

		// Step 5 - Clean the environment by closing channel and connection
		channel.close();
		connection.close();
		System.out.println("Consumer disconnected from broker!!!!!");

	}

}
