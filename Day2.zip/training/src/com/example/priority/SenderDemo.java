package com.example.priority;

import java.util.HashMap;
import java.util.Map;

import com.rabbitmq.client.AMQP.BasicProperties;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SenderDemo {

	public static void main(String[] args) throws Exception {

		// Step 1 - Making a connection to broker
		// Broker URL ---- amqp://localhost:8000
		ConnectionFactory connectionFactory = new ConnectionFactory();
		connectionFactory.setHost("localhost"); // localhost
		connectionFactory.setPort(8000); // 5672
		connectionFactory.setUsername("ritesh"); // guest
		connectionFactory.setPassword("secret"); // guest

		Connection connection = connectionFactory.newConnection();

		// Step 2 - Opening a channel to broker using available connection
		// Session which is used to do messaging
		Channel channel = connection.createChannel();
		
		//Preparing headers to attach to message envelope
		BasicProperties basicProperties = new BasicProperties();
		
		// Step 3 - Create a publisher using available channel to send message to an
		// exchange
		
		basicProperties = basicProperties.builder().priority(2).build();
		channel.basicPublish("", "ShopQ", basicProperties, "2 Dell Laptop".getBytes());
		
		basicProperties = basicProperties.builder().priority(5).build();
		channel.basicPublish("", "ShopQ", basicProperties, "5 iPhone 7+".getBytes());
		
		basicProperties = basicProperties.builder().priority(10).build();
		channel.basicPublish("", "ShopQ", basicProperties, "1 Sony 56 inch LED".getBytes());
		
		
		System.out.println("Message Sending Done!!!!!");

		// Step 4 - Clean the environment by closing channel and connection
		channel.close();
		connection.close();
	}

}
